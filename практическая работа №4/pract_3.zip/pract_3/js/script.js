/*alert("ffff");
let c1=document.quertySelector('Duis:nth-child(1)');
c1.click(function Border(){
	document.quertySelector('Duis:nth-child(1)').style.border="2px solid #000";
})*/

class User{constructor(name,password,tel,mail){
this.name=name;
this.mail=bakhchevnikov@bk.ru;
this.tel=89515205233;
this.password=lenka123matilenka;
console.log("name-"+this.name+" "+"mail-"+this.mail+" "+"tel-"+this.tel+" "+"password-"+this.password);
}
}

class Admin extends User{
Remove(){
	el.classList.remove('User');
}
}

/*function Admin(){
this.name=name;
this.mail=bakhchevnikov@bk.ru;
this.tel=89515205233;
this.password=lenka123matilenka;
}
Admin.prototype=Object.creat(User.prototype);

Admin.prototype.remove=function(){
	el.classList.remove('User');
}*/
